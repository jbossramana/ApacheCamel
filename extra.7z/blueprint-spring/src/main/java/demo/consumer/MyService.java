package demo.consumer;


import org.springframework.web.client.RestTemplate;

public class MyService {
    private RestTemplate restTemplate;

    // Setter for Blueprint injection
    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String fetchData() {
        String url = "http://date.jsontest.com/";
        String response = restTemplate.getForObject(url, String.class);
    //    System.out.println("Response: " + response);
        return response;
    }
}

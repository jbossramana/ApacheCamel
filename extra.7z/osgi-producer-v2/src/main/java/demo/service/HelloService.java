package demo.service;


public interface HelloService {
    String sayHello();
}

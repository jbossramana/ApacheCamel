package demo.service;


public class HelloServiceImpl implements HelloService {
    @Override
    public String sayHello() {
        return "Hello from version 2.0.0";
    }
}

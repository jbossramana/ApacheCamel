package demo.consumer;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import demo.service.HelloWorldSvc;

public class Client {
    private static final Logger logger = LoggerFactory.getLogger(Client.class);

    private HelloWorldSvc helloWorldSvc;

    // Getter and Setter for HelloWorldSvc
    public HelloWorldSvc getHelloWorldSvc() {
        return helloWorldSvc;
    }

    public void setHelloWorldSvc(HelloWorldSvc helloWorldSvc) {
        this.helloWorldSvc = helloWorldSvc;
    }

    // Initialization method
    public void init() {
        logger.info("OSGi client started.");
        
        if (helloWorldSvc != null) {
            logger.info("Calling sayHello() method.");
            logger.info(helloWorldSvc.sayHello()); // Invoke the OSGi service!
        } else {
            logger.warn("HelloWorldSvc is not set. Cannot invoke sayHello().");
        }
    }
}

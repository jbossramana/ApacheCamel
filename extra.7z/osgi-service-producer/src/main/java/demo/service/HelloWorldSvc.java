package demo.service;


public interface HelloWorldSvc
{
public String sayHello();
}
package demo.service;


public class HelloWorldSvcImpl implements HelloWorldSvc {
public String sayHello()
{
  return "Hello World!";
}
}
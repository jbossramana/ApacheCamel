package demo.api;

public class InfoAPIService {

	public String info()
	{
		return "Simple Consumer API";
	}
}

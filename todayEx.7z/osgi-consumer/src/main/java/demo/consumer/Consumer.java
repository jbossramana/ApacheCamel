package demo.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import demo.service.HelloService;
import demo.service.HelloServiceImpl;

public class Consumer {

    // Create a logger instance for the class
    private static final Logger logger = LoggerFactory.getLogger(Consumer.class);

    public void execute() {
        // Directly create an instance of the service
        HelloService service = new HelloServiceImpl();

        // Log messages using different levels
        logger.info("Executing Consumer...");

        try {
            String response = service.sayHello();
            logger.info("Service Response: {}", response); // Log with dynamic value
        } catch (Exception e) {
            logger.error("Error occurred while executing service: {}", e.getMessage(), e);
        }
    }
}

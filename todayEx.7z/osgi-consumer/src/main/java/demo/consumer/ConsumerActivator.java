package demo.consumer;


import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class ConsumerActivator implements BundleActivator {

    @Override
    public void start(BundleContext context) throws Exception {
        // Create an instance of Consumer
        Consumer consumer = new Consumer();
        consumer.execute();  // Call the execute method to run logic
    }

    @Override
    public void stop(BundleContext context) throws Exception {
        // Cleanup if necessary
    }
}

package demo.internal;

public class InfoService {

	public String info()
	{
		return "Internal Service";
	}
}
